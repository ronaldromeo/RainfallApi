﻿using Microsoft.AspNetCore.Mvc;
using RainfallApi.Controllers;

namespace RainfallApi.Service
{
    public class RainfallApiService
    {
        /// <summary>
        /// Get the rainfall data
        /// </summary>
        /// <param name="stationId">The id of the reading station</param>
        /// <param name="count">The number of readings to return</param>
        /// <returns></returns>
        public IActionResult GetRainfall(string stationId, int? count)
        {
            var inMemorySettings = new Dictionary<string, string> {
            };

            var _appsettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            inMemorySettings.Add("ApiUrl", _appsettings["ApiUrl"]);
            IConfiguration _config = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build(); ;
            ReadingsController controller = new ReadingsController(_config);
            return controller.GetRainfall(stationId, count);
        }
    }
}
