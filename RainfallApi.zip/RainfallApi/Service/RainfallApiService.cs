﻿using Microsoft.AspNetCore.Mvc;
using RainfallApi.Controllers;

namespace RainfallApi.Service
{
    public class RainfallApiService
    {
        public IActionResult GetRainfall(string stationId, int? count)
        {
            var inMemorySettings = new Dictionary<string, string> {
                  // {"ApiUrl", "TopLevelValue"}
            };

            var _appsettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            inMemorySettings.Add("ApiUrl", _appsettings["ApiUrl"]);
            IConfiguration _config = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build(); ;
            ReadingsController controller = new ReadingsController(_config);
            return controller.GetRainfall(stationId, count);
        }
    }
}
