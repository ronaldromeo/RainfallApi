﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RainfallApi.Models;
using System.ComponentModel;
using Swashbuckle.AspNetCore.Annotations;
using Microsoft.AspNetCore.Mvc.ActionConstraints;

namespace RainfallApi.Controllers
{
    [Route("id/stations/{stationId}/readings")]
    [ApiController]
    public class ReadingsController : ControllerBase
    {
        IConfiguration _config;
        public ReadingsController(IConfiguration config)
        {
            _config = config;
        }

        [SwaggerOperation(Summary = "Get rainfall readings by station Id", Description = "Retrieve the latest readings for the specified stationId", Tags = new string[] { "Rainfall" }, OperationId = "get-rainfall")]
        [HttpGet(Name = "GetRainfall/{stationId}/{count?}")]
        public IActionResult GetRainfall(string stationId, int? count)
        {
            //   StatusCodeResult _statusCode = null;
            if (count == 0 || count == null)
            {
                count = 10;
            }

            HttpResponseMessage _response = new HttpResponseMessage();

            RainfallReadingResponse _rainfallReadingResponse = new RainfallReadingResponse();
            ErrorResponse _errorResponse = new ErrorResponse();
            try
            {

                //   DateTime dateTime = DateTime.Parse("2024/02/30");
                HttpClient client = new HttpClient();
                RainfallReadingModel _rawResult = new RainfallReadingModel();
                string url = _config.GetSection("ApiUrl").Get<string>();
                url = url.Replace("@stationId", stationId.ToString()).Replace("@count", count.ToString());
                _response = client.GetAsync(url).Result;
                if (_response.StatusCode == System.Net.HttpStatusCode.OK && _response.IsSuccessStatusCode)
                {
                    string _resultText = _response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(_resultText))
                    {
                        _rawResult = JsonConvert.DeserializeObject<RainfallReadingModel>(_resultText);
                        if (_rawResult.items.Count == 0)
                        {
                            //  _errorResponse.Message = string.Empty;
                            _errorResponse.Title = Constants.ErrorResponseTitle;
                            _errorResponse.Description = Constants.ErrorResponseDescriptionInvalidStationId;
                            return NotFound(_errorResponse);
                            // return NotFound(_response);
                        }
                        else
                        {
                            List<Item> _readings = new List<Item>();
                            foreach (var _item in _rawResult.items)
                            {
                                _readings.Add(new Item { AmountMeasured = (decimal)_item.value, DateMeasured = _item.dateTime });
                            }

                            _rainfallReadingResponse.Items = _readings;
                            _rainfallReadingResponse.Description = Constants.SuccessResponseDescription;
                            _rainfallReadingResponse.Title = Constants.SuccessResponseTitle;

                            return Ok(_rainfallReadingResponse);
                        }
                    }
                }
                else if (_response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    //_errorResponse.Message = string.Empty;
                    _errorResponse.Title = Constants.ErrorResponseTitle;
                    _errorResponse.Description = Constants.ErrorResponseDescriptionInvalidRequest;
                    return BadRequest(_errorResponse);
                }
                else if (_response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
                {
                    //_errorResponse.Message = string.Empty;
                    _errorResponse.Title = Constants.ErrorResponseTitle;
                    _errorResponse.Description = Constants.ErrorResponseDescriptionInternalServerError;
                    return StatusCode(500, _errorResponse);
                }
                return Ok(null);
            }
            catch
            {
                //_errorResponse.Message = string.Empty;
                _errorResponse.Title = Constants.ErrorResponseTitle;
                _errorResponse.Description = Constants.ErrorResponseDescriptionInternalServerError;
                return StatusCode(500, _errorResponse);
            }
        }
    }
}
