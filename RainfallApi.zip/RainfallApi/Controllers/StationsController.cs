﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RainfallApi.Models;

namespace RainfallApi.Controllers
{
    [Route("api/id/[controller]")]
    [ApiController]
    public class StationsController : ControllerBase
    {
        //private readonly ILogger<StationsController> _logger;
        //public StationsController(ILogger<StationsController> logger)
        //{
        //    _logger = logger;
        //}

        public StationsController()
        {
        }

        [HttpGet(Name = "GetRainfall/{stationId}")]
        public IActionResult GetRainfall(string stationId)
        {
            StatusCodeResult _statusCode = null;

            try
            {
                HttpClient client = new HttpClient();

                RainfallReadingModel _result = new RainfallReadingModel();
                string url = string.Concat("https://environment.data.gov.uk/flood-monitoring/id/stations/", stationId, "/readings?_sorted&_limit=10");
                HttpResponseMessage response = client.GetAsync(url).Result;
                if (response.StatusCode == System.Net.HttpStatusCode.OK && response.IsSuccessStatusCode)
                {
                    string _resultText = response.Content.ReadAsStringAsync().Result;
                    if (!string.IsNullOrEmpty(_resultText))
                    {
                        _result = JsonConvert.DeserializeObject<RainfallReadingModel>(_resultText);
                        if (_result.items.Count == 0)
                        {
                            _statusCode = new StatusCodeResult(204);
                        }
                        else
                        {
                            return Ok(_result.items);
                        }

                    }
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    _statusCode = new StatusCodeResult(400);
                }
            }
            catch
            {
                _statusCode = new StatusCodeResult(500);
            }
            return _statusCode;
        }
    }
}
