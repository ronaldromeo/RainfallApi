﻿namespace RainfallApi.Models
{

    public interface IBaseResponse
    {
        //   string Title { get; set; }
        string Message { get; set; }
    }

    public class RainfallReadingResponse : IBaseResponse
    {
        string _Title = string.Empty;
        string _Description = string.Empty;

        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        public string Message
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public List<Item> Items { get; set; }
    }

    public class Item
    {
        //public string Title { get; set; }
        public DateTime DateMeasured { get; set; }
        public Decimal AmountMeasured { get; set; }
    }

    public class Error
    {
        public string PropertyName { get; set; }
        public string Message { get; set; }
    }

    public class ErrorResponse : IBaseResponse
    {
        //string _Title = string.Empty;
        string _Message = string.Empty;

        //private string Title
        //{
        //    get { return _Title; }
        //    set { _Title = value; }
        //}

        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        
        public List<Error> Detail { get; set; }

    }
}
