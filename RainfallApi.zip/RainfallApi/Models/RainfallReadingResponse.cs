﻿namespace RainfallApi.Models
{

    public interface IBaseResponse
    {
        string Title { get; set; }
        string Description { get; set; }
    }

    public class RainfallReadingResponse : IBaseResponse
    {
        string _Title = string.Empty;
        string _Description = string.Empty;

        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public List<Item> Items { get; set; }
    }

    public class Item
    {
        public DateTime DateMeasured { get; set; }
        public Decimal AmountMeasured { get; set; }
    }

    public class ErrorResponse : IBaseResponse
    {
        string _Title = string.Empty;
        string _Description = string.Empty;

        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string Message { get; set; }

        public bool AdditionalProperties { get; set; }
    }
}
