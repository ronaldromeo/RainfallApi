﻿namespace RainfallApi
{
    public static class Constants
    {
        public static readonly string ErrorResponseTitle = "Error Response";
        public static readonly string ErrorResponseDescriptionInvalidStationId = "No readings found for the specified stationId";
        public static readonly string SuccessResponseTitle = "Rainfall reading response";
        public static readonly string SuccessResponseDescription = "Details of rainfall reading";
        public static readonly string ErrorResponseDescriptionInvalidRequest = "Invalid request";
        public static readonly string ErrorResponseDescriptionInternalServerError = "Internal Server error";
    }
}
