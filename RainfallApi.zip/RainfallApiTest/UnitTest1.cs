using RainfallApi;
using RainfallApi.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RainfallApi.Service;
using RainfallApi.Models;

namespace RainfallApiTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void HappyPathTest()
        {
            RainfallApiService service = new RainfallApiService();
            IActionResult _actual = service.GetRainfall("3680", null);
            var _expected = _actual as OkObjectResult;
            Assert.IsNotNull(_expected);
        }

        [Test]
        public void UnhappyPathWrongStationIdTest()
        {
            RainfallApiService service = new RainfallApiService();
            IActionResult _actual = service.GetRainfall("1", null);
            var _expected = _actual as OkObjectResult;
            Assert.IsNotNull(_expected);
        }

        [Test]
        public void UnhappyPathNoStationIdTest()
        {
            RainfallApiService service = new RainfallApiService();
            IActionResult _actual = service.GetRainfall("", null);
            var _expected = _actual as OkObjectResult;
            Assert.IsNotNull(_expected);
        }
    }
}